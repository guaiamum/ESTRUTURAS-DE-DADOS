#ifndef __EstruturasDeDados__
#define __EstruturasDeDados__ 1

typedef enum 	{	BLACK,
					RED,
					GREEN,
					BLUE,
					MAGENTA,
					CYAN,
					YELLOW,
					GRAY
				} eCor;

typedef struct {	float x;
					float y;
					float z;
			   } tPonto;
			   
																		
#endif		// __EstruturasDeDados__
